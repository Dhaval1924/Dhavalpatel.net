using CollegeFestMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace CollegeFestMVC.Controllers;

public class FestController : Controller
{
    private static List<Participant> participants = new()
    {
        new Participant
        {
            ParticipantId = 1,
            ParticipantName = "Rahul Patel",
            Email = "rahul@gmail.com",
            Department = "Computer Engineering",
            Year = "3rd Year",
            EventName = "Coding Competition",
            IsTeamEvent = true,
            RegistrationFee = 500,
            IsRegistered = true
        }
    };

    public IActionResult Index()
    {
        return View(participants);
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Register(Participant participant)
    {
        if (!ModelState.IsValid)
        {
            return View(participant);
        }

        participant.ParticipantId = participants.Count + 1;

        if (participant.EventName == "Quiz")
            participant.RegistrationFee = 0;
        else if (participant.EventName == "Coding Competition")
            participant.RegistrationFee = 500;
        else
            participant.RegistrationFee = 1000;

        participant.IsRegistered = true;

        participants.Add(participant);

        return RedirectToAction("Index");
    }

    public IActionResult Details(int id)
    {
        var participant = participants.FirstOrDefault(p => p.ParticipantId == id);

        if (participant == null)
        {
            return NotFound();
        }

        return View(participant);
    }

    public IActionResult Welcome()
    {
        return View();
    }
}